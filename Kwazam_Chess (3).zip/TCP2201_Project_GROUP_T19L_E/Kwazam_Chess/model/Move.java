package Kwazam_Chess.model;

//-----Project Information-----
// Project Title: Kwazam_Chess
// Design Pattern: MVC / Factory Method
// Teammates
// LEE YI YANG (242UC2451A) [Leader]
// CHIN JING XUAN (1221101397)
// VINNOSH RAU A/L SAMUDRAM (1211108264)

public class Move{
    int oldCol;
    int oldRow;
    int newCol;
    int newRow;
    
    Piece piece;
    Piece capture;
    
    public Move(Board board, Piece piece, int newCol, int newRow){
        
        this.oldCol = piece.col;
        this.oldRow = piece.row;
        this.newCol = newCol;
        this.newRow = newRow;
        
        this.piece = piece;
        this.capture = board.getPiece(newCol, newRow);
    }
}
